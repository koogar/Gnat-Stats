
First Reflow and check the solder joints properly on the BluePill headers

This Sketch will test the wiring of your Phat-Stats setup
If the test Sketch works your wiring is good.


If Phat-Stats still does not work see below.

	1) You are using the wrong Arduino core for the BluePill

	2) https://github.com/rogerclarkmelbourne/Arduino_STM32/wiki/Installation


	Place the extracted Arduino_STM32 folder in Documents/Arduino/Hardware
	 https://github.com/rogerclarkmelbourne/Arduino_STM32/archive/master.zip


	Select the correct board from within the Arduino IDE (Generic STM32F103c Series)

/*Adafruit_GFX Version 1.8.0 and higher doesn't compile for ESP8266 & STM32 Boards
  Downgrade to Adafruit_GFX Version 1.7.5 in the library manager.*/


