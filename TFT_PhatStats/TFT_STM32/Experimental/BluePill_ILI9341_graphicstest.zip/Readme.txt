This will test the wiring of your Phat-Stats setup

If this works your wiring is good.

If Phat-Stats still does not work see below

1) You are using the wrong Arduino core for the BluePill

2) https://github.com/rogerclarkmelbourne/Arduino_STM32/wiki/Installation


Place the extracted Arduino_STM32 folder in Documents/Arduino/Hardware
 https://github.com/rogerclarkmelbourne/Arduino_STM32/archive/master.zip


Select the correct board from within the Arduino IDE (Generic STM32F103c Series)

