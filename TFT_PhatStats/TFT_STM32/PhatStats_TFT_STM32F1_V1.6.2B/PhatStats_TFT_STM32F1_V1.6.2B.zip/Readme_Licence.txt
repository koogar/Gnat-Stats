

  GNATSTATS/PHATSTATS PC Performance Monitor   Rupert Hirst & Colin Conway � 2016
  HardwareSerialMonitor PC Serial Client       Rupert Hirst & Colin Conway � 2016

  http://tallmanlabs.com  & http://runawaybrainz.blogspot.com/

  Licence
  -------

  Attribution-NonCommercial-ShareAlike  CC BY-NC-SA

  This license lets others remix, tweak, and build upon your work non-commercially, as long as they credit you and license their   new creations under the identical terms.

  https://creativecommons.org/licenses/

  Notes:

  The application will not detect integrated graphics as a GPU!!!
  Presently HardwareSerialMonitor does not like virtual Bluetooth COM ports present on the users PC!!!

  ALWAYS RUN "HARDWARE SERIAL MONITOR" AS ADMIN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  This project, assumes you have a above average experience with Arduino, the IDE and the compatible boards available.

